# About
**Advance ticket bot with 15 ticket systems and 1 beta. To make users more comfortable using this bot. Comes with a ticket log to see who opened the ticket and view the transcript ticket. Make it easy for users to delete tickets with discord-modal.**
# Feature
- Advance ticket</br>
- 16 System Ticket</br>
- 24/7 Online</br>
- Easy To Use</br>
- Slashcommand</br>
- Discord-modal</br>