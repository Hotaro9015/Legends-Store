## Ticket Bot
- **Advance Ticket Bot**
- **25 Ticket System with 1 Beta**
- **Ticket Logs**
- **24/7 Online**
- **Slash Command**
## Install Bot
- [**Replit**](https://replit.com/github/Hotaro9015/)
## Uptime Your Bot
- [**Website**](https://uptimerobot.com/)
- [**Tutorial**](https://youtube.com/)
## How To Install
1. **Go To Shell**
2. **Type "npm install" Enter**
3. **Wait module installed**
4. **Go To Secret**
5. **Make a New Secret**
- Key : **token**
- Value : [**Bot Token**](https://discord.com/developers/applications)
6. **Click Add New Secret**
7. **Click Run**
8. **Enjoy You Bot**
## Bug & Masalah Menginstal
- **Kesusahan Dalam Menginstal Bot?**
- **Dm Hōtarō Oreki#9015**
- **Or [Join To Server](https://dsc.gg/nezuko-cm)**
